package go_logger

// logger config interface
type Config interface {
	Name() string
}
