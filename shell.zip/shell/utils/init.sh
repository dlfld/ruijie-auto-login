userId=
password=
timeInterval=3600

log_path=./output.log
log_save_day=7
log_clear_day=30

network='校园网'
